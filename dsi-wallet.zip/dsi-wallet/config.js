// Settings for DSi Wallet. Leave the Google Drive field empty to use this device only.
// See README, section 2, for how to get the client ID.
window.WALLET_CONFIG = {
  appName: 'DSi Wallet',
  googleClientId: '', // Google Cloud → Credentials → OAuth client ID (Web application), looks like 1234-abc.apps.googleusercontent.com
};
